class WelcomeController < ApplicationController
  def home
  end

  def login

  end
  def register

  end
  def products

  end
  def product_details

  end
end
