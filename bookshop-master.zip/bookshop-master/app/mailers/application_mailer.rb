class ApplicationMailer < ActionMailer::Base
  default from: "bookshop.k.j@gmail.com"
  layout 'mailer'
end
